    <footer>
     <div class="row" style="max-width: 1200px;margin: 0 auto">
            <div class="col-md-6">
            	 <div class="content_footer">
                        <div class="contact_footer">
                            <p>Liên kết mạng xã hội: </p>
                            <div class="img_footer">
                                <a href="https://www.facebook.com/groups/traitimquadiacau"><i class="fab fa-facebook"></i></a>  
                                <a href=""><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="contact_footer">
                            <a href="" class="icon_footer"><i class="fas fa-map-marker-alt"></i></a>
                            <p><span>Địa chỉ:</span> Tầng 7, Số 42, Trần Vỹ, Mai Dịch, Cầu Giấy, Hà Nội</p>
                        </div>
                        <div class="contact_footer">
                            <a class="icon_footer" href="bantruyenthong.hoe@gmail.com"><i class="fas fa-envelope-open-text"></i></a>
                            <p><span>Email:</span><a href="bantruyenthong.hoe@gmail.com"> bantruyenthong.hoe@gmail.com</a> </p>
                        </div>
                   </div>
            </div>
            <div class="col-md-6">
            	 <div class="content_footer">
                        <div class="contact_footer">
                            <p>Liên kết mạng xã hội: </p>
                            <div class="img_footer">
                                <a href="https://www.facebook.com/groups/traitimquadiacau"><i class="fab fa-facebook"></i></a>  
                                <a href=""><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="contact_footer">
                            <a href="" class="icon_footer"><i class="fas fa-map-marker-alt"></i></a>
                            <p><span>Địa chỉ:</span> Tầng 7, Số 42, Trần Vỹ, Mai Dịch, Cầu Giấy, Hà Nội</p>
                        </div>
                        <div class="contact_footer">
                            <a class="icon_footer" href="bantruyenthong.hoe@gmail.com"><i class="fas fa-envelope-open-text"></i></a>
                            <p><span>Email:</span><a href="bantruyenthong.hoe@gmail.com"> bantruyenthong.hoe@gmail.com</a> </p>
                        </div>
                   </div>
            	
            </div>
    </div>
        <div class="row">
            <div class="col-md-12">
                <p style="text-align:center">© 2021 HOE, Chào mừng đến với Trái Tim Quả Địa Cầu</p>
            </div>
        </div>

    </footer><?php /**PATH C:\xampp\htdocs\Hoe\resources\views/layout/footer.blade.php ENDPATH**/ ?>